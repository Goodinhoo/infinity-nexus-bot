const warns = [
    { warnLevel: 3, level: '1' },
    { warnLevel: 1, level: '1' },
    { warnLevel: 2, level: '1' },
    { warnLevel: 4, level: '2' },
    { warnLevel: 1, level: '1' },
  ];
  
  const highestLevelWarn = warns.reduce((highest, warn) => {
    if (warn.level === '1' && warn.warnLevel > (highest ? highest.warnLevel : 0)) {
      return warn;
    } else {
      return highest;
    }
  }, null);
  
  if (highestLevelWarn) {
    console.log('O warn com o maior warnLevel e level 1 é:', highestLevelWarn);
  } else {
    console.log('Nenhum warn com level 1 encontrado.');
  }
  